"""
utils/sheets_writer.py — Единая выгрузка DataFrame в Google Sheets.

Заменяет 6 копий блока «fillna → applymap → rows → ws.update».
"""

import time
from typing import Optional

import pandas as pd

from pricecraft.utils.module_logger import write_log


def upload_df_to_sheet(
    ws,
    df: pd.DataFrame,
    clear_first: bool = True,
    sheet_label: str = "лист",
) -> None:
    """
    Очищает лист Google Sheets и записывает DataFrame.

    Args:
        ws: gspread Worksheet объект.
        df: DataFrame для записи.
        clear_first: Очистить лист перед записью.
        sheet_label: Имя листа для логов.
    """
    # 1) Очистка данных
    df_clean = df.copy()
    df_clean = df_clean.fillna("")
    df_clean = df_clean.applymap(
        lambda x: x.item() if hasattr(x, "item") else x
    )
    df_clean = df_clean.reset_index(drop=True)

    # 2) Формируем rows: заголовок + данные
    rows = [df_clean.columns.tolist()] + df_clean.astype(str).values.tolist()

    # 3) Проверка непустых строк
    non_empty = [any(cell.strip() for cell in r) for r in rows[1:]]
    write_log(
        f"[{sheet_label}] Строк: {len(df_clean)}, "
        f"непустых: {sum(non_empty)}"
    )

    # 4) Очистка листа
    if clear_first:
        ws.clear()
        time.sleep(0.5)

    # 5) Запись
    if len(df_clean) > 0 and sum(non_empty) > 0:
        ws.update(
            range_name="A1",
            values=rows,
            value_input_option="USER_ENTERED",
        )
        write_log(f"[{sheet_label}] ✅ Записано {len(df_clean)} строк")
    elif len(df_clean) > 0:
        # Все строки пустые — маркер
        rows_marked = [rows[0]] + [
            [("!empty!" if i == 0 else "")] + r[1:]
            for i, r in enumerate(rows[1:])
        ]
        ws.update(
            range_name="A1",
            values=rows_marked,
            value_input_option="USER_ENTERED",
        )
        write_log(f"[{sheet_label}] ⚠️ Записаны пустые строки с маркером")
    else:
        write_log(f"[{sheet_label}] DataFrame пуст — только заголовки")
