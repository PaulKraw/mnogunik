"""
config/secrets.py — Все секреты читаются из переменных окружения.

Ни один API-ключ, пароль или токен не хранится в коде.
Источник: файл .env в корне проекта (загружается через python-dotenv).
"""

import os

# Попытка загрузить .env
try:
    from dotenv import load_dotenv
    _env = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '.env')
    load_dotenv(_env)
except ImportError:
    pass


# ═══════════════════════════════════════════
# OZON API
# ═══════════════════════════════════════════

OZON_CLIENT_ID: str = os.environ.get("OZON_CLIENT_ID", "")
OZON_API_KEY: str = os.environ.get("OZON_API_KEY", "")

OZON_HEADERS: dict = {
    "Client-Id": OZON_CLIENT_ID,
    "Api-Key": OZON_API_KEY,
    "Content-Type": "application/json",
}

OZON_API_URL: str = "https://api-seller.ozon.ru/v1/product/import/prices"


# ═══════════════════════════════════════════
# GOOGLE SHEETS
# ═══════════════════════════════════════════

SPREADSHEET_ID: str = os.environ.get(
    "SPREADSHEET_ID", "1fLrruYkw0JOOszb6q4bUpNYImflxFkdem57pQPc0qnQ"
)
SPREADSHEET_CLROWS_ID: str = os.environ.get(
    "SPREADSHEET_CLROWS_ID", "1tLVJCMAqYxzHw1SgwT8UcaM4eH6tccMhg8szjBnnkHk"
)


# ═══════════════════════════════════════════
# WEB PANEL
# ═══════════════════════════════════════════

WEB_PASSWORD: str = os.environ.get("PRICECRAFT_WEB_PASSWORD", "")

# Mnogunik integration
MNOGUNIK_RUN_URL: str = os.environ.get(
    "MNOGUNIK_RUN_URL", "https://mnogunik.ru/mnogunik/run.php"
)
MNOGUNIK_RUN_KEY: str = os.environ.get("MNOGUNIK_RUN_KEY", "")
