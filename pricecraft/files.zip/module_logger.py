"""
utils/module_logger.py — Единое логирование для всех модулей pricecraft.

Заменяет 8 копий write_log() и write_status() в modules/*.py.
"""

import json
import os
from datetime import datetime
from typing import Optional

from pricecraft.config.settings import LOG_FILE, STATUS_FILE, RUNNERS_DIR


def _ensure_dirs() -> None:
    """Создаёт папку runners если не существует."""
    os.makedirs(RUNNERS_DIR, exist_ok=True)


def write_log(msg: str) -> None:
    """
    Записывает сообщение в лог-файл и stdout.

    Args:
        msg: Текст сообщения.
    """
    _ensure_dirs()
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"{ts} | {msg}\n"

    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(line)

    print(msg)


def write_status(
    status: str,
    message: str = "",
    module: str = "unknown",
) -> None:
    """
    Обновляет файл status.json с текущим состоянием модуля.

    Args:
        status: running / idle / error / finished.
        message: Описание текущего шага.
        module: Имя модуля.
    """
    _ensure_dirs()
    data = {
        "module": module,
        "status": status,
        "message": message,
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }
    with open(STATUS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
